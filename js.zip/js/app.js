class Show {
    constructor(title, episodesW, episodesT, rating, comments) {
        this.title = title;
        this.episodesW = episodesW;
        this.episodesT = episodesT;
        this.rating = rating;
        this.comments = comments;
    }
}

class UI {
    static displayShows() {
        const shows = Store.getShows();

        shows.forEach((show) => UI.addShow(show));
    }


    //Get Show
    static addShow(show) {
        const list = document.querySelector('#show-list');
        const row = document.createElement('tr');
        let completed;

        if(show.episodesT == show.episodesW)
        {
            completed = 'Completed';
        } else {
            completed = 'Incomplete';
        }
        row.innerHTML = `
        <td>${show.title}</td>
        <td>${show.episodesW} / ${show.episodesT}</td>
        <td>${show.rating}</td>
        <td>${completed}</td>
        <td>${show.comments}</td>
        <td><a href="#" class="btn btn-danger btn-sm delete">X</a></td>
    `;

    list.appendChild(row);
    }

    static deleteShow(el) {
        if(el.classList.contains('delete')) { //delete is class in the X
            el.parentElement.parentElement.remove(); //parent is just the X td, parent parent is the whole row
        }
    }
}

//Store class: handles storage
class Store {
    static getShows() {
        let shows;
        if(localStorage.getItem('shows') === null) { //if empty
            shows = [];
        } else {
            shows = JSON.parse(localStorage.getItem('shows'));
        }
        return shows;
    }

    static addShow(show) {
        const shows = Store.getShows();
        shows.push(show);
        localStorage.setItem('shows', JSON.stringify(shows));
    }

    static removeShow(title) {
        const shows = Store.getShows();

        shows.forEach((show, index) => {
            if(show.title === title) {
                shows.splice(index, 1);
            }
        });

        localStorage.setItem('shows', JSON.stringify(shows));
    }
}

document.addEventListener('DOMContentLoaded', UI.displayShows);

document.querySelectorAll('#show-form')[2].addEventListener('submit', (e) => {
    e.preventDefault();
    
    var element = document.getElementById('rating');
    var option = element.options[element.selectedIndex].value;

    const title = document.querySelector('#title').value;
    const episodesW = document.querySelector('#epW').value;
    const episodesT = document.querySelector('#epT').value;
    const rating = option;
    const comments = document.querySelector('#comments').value;


    if(title == "" || episodesW == "" || episodesT == "" || rating == "Choose") { //if anything is empty
        console.log('add that shit');

    } else if (isNaN(episodesW) || isNaN(episodesT)) { //if episodes are not integers
        console.log('episodes must contain a #');

    } else if (episodesW > episodesT) { //if watched is larger than total
        console.log('Watched cannot be larger than total');

    } else { //everything right
        const show = new Show(title, episodesW, episodesT, rating, comments);

        //add to UI
        UI.addShow(show);

        //save locally
        Store.addShow(show);
    }
});

document.querySelector('#show-list').addEventListener('click', (e) => {
    //delete
    UI.deleteShow(e.target);

    Store.removeShow(e.target.parentElement.previousElementSibling.previousElementSibling.previousElementSibling.previousElementSibling.previousElementSibling.textContent);
});